package com.example.SimpleTaskManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleTaskManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
